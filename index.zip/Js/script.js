document.getElementById("contactForm").addEventListener("submit", function(e){

e.preventDefault();

let name = document.getElementById("name").value;
let email = document.getElementById("email").value;
let message = document.getElementById("message").value;

let msg = document.getElementById("formMessage");

if(name === "" || email === "" || message === ""){
msg.innerText = "Please fill in all fields.";
msg.style.color = "red";
return;
}

msg.innerText = "Form submitted successfully!";
msg.style.color = "green";

});